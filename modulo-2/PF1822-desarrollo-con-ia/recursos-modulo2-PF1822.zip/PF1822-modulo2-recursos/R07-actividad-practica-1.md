# PF1822 · Módulo 2 · R07 — Actividad práctica 1 (C2)

**Estado:** borrador · **Va en:** Anexo N°2, sección VI b) · **Guía:** Anexo N°7, num. 7, pág. 109
**Para el 7,0:** 2 actividades prácticas distintas que permitan adquirir la habilidad.
Siguen el ejemplo de la guía (pág. 110): una de **resolución de problemas** apoyada en
tutoriales y videos, y otra de **análisis de caso** con **gamificación y simulación**,
ambas con respuesta modelada.

> **Aviso para quien revise:** el código de las respuestas modeladas está escrito y revisado
> a mano, pero **no se ejecutó** en la máquina donde se produjo este kit (no tiene Python).
> Antes de publicarlo, el tutor lo corre una vez con `pytest` y con una clave de prueba.

| | Actividad 1 | Actividad 2 |
| --- | --- | --- |
| Nombre | Un cliente de API para el resumidor | Laboratorio de prompts y métricas |
| Técnica | Resolución de problemas | Análisis de caso + simulación con tablero de puntajes |
| AE que cubre | AE1, AE2 | AE3, AE4 |
| Indicadores | 1.2, 1.3, 2.1, 2.2, 2.3 | 3.1, 3.2, 3.3, 4.1, 4.2, 4.3 |
| Tramo del módulo | 1 y 2 | 3 y 4 |
| Tiempo estimado | 6 h (2 h guiadas + 4 h autónomas) | 6 h (1,5 h sincrónica + 4,5 h autónomas) |
| Apoyos | Notebook guiado R05, cápsulas R03 | Video interactivo R06 |
| Producto | Diagrama + `cliente_ia.py` + `test_cliente_ia.py` | Notebook del pipeline + registro de prompts + tabla de métricas |
| Se evalúa con | Rúbrica de solución (B2-1) | Rúbrica de solución (B2-1) + bitácora (B4-d) |

---

## Actividad 1 · Un cliente de API para el resumidor

### Enunciado para el participante

La mesa de ayuda de Nube Sur (empresa ficticia) quiere un resumidor de tickets. Antes de
escribir prompts, el equipo necesita dos cosas: saber cómo va a estar armada la aplicación
y tener una pieza de código confiable para hablar con el modelo.

**Parte A — Arquitectura (AE1).** Dibuja el diagrama funcional del resumidor con estos
componentes: la aplicación de la mesa de ayuda (cliente), el servidor que expone la API
interna, el módulo de preprocesamiento, el modelo de IA externo y una base de datos o
*vector store*. Explica en una línea qué hace cada uno y responde: **¿dónde se guarda la
clave de la API y por qué no puede estar en el cliente?** Justifica tu arquitectura con dos
criterios: escalabilidad, seguridad, costo o mantenimiento.

**Parte B — Cliente de API (AE2).** Programa en Python el módulo `cliente_ia.py` con una
clase `ClienteIA` que:
1. lea la clave y los nombres de modelo desde **variables de entorno**, nunca desde el código;
2. liste los modelos disponibles con una solicitud **GET**;
3. genere texto con una solicitud **POST** al endpoint de chat, con `temperature` y límite de tokens configurables, y devuelva el texto y los tokens usados;
4. obtenga **embeddings** de una lista de textos con una solicitud **POST**;
5. informe los errores HTTP con un mensaje claro;
6. esté documentada con **docstrings**.

Escribe además `test_cliente_ia.py` con **al menos tres pruebas unitarias** que se ejecuten
**sin conexión**, simulando la API.

**Entrega:** el diagrama (imagen o Mermaid), los dos archivos `.py`, la salida de `pytest`
y un `README.md` breve. Tu clave **no** puede aparecer en ningún archivo ni captura.

### Respuesta modelada

**Parte A — diagrama de referencia:**

```mermaid
flowchart LR
  U[App de la mesa de ayuda<br/>navegador] -->|ticket| S[Servidor API interno<br/>guarda la clave]
  S --> P[Preprocesamiento<br/>limpia HTML, firmas, datos personales]
  P --> M[Modelo de IA externo<br/>vía API REST]
  M -->|resumen| S
  S --> DB[(Base de datos /<br/>vector store)]
  S -->|resumen + prioridad| U
```

| Componente | Función |
| --- | --- |
| App de la mesa de ayuda | Muestra el ticket y su resumen; nunca conoce la clave. |
| Servidor API interno | Recibe el ticket, orquesta el flujo y es el único que guarda la clave (variable de entorno). |
| Preprocesamiento | Limpia el texto y quita datos personales antes de enviarlo: menos tokens y menos riesgo. |
| Modelo de IA externo | Genera el resumen y los embeddings. |
| Base de datos / vector store | Guarda tickets, resúmenes y embeddings para buscar tickets parecidos. |

*Por qué la clave no va en el cliente:* todo lo que llega al navegador puede leerlo
cualquiera; una clave expuesta se usa para gastar a cuenta de la empresa.
*Justificación modelo:* **seguridad**, porque la clave y los datos personales quedan del lado
del servidor; **escalabilidad**, porque el servidor puede encolar tickets y procesarlos en
lote sin cambiar la aplicación de la mesa de ayuda.

**Parte B — `cliente_ia.py` de referencia:**

```python
"""Cliente mínimo y reutilizable para APIs de modelos generativos compatibles con OpenAI."""
from __future__ import annotations

import os

import httpx

class ErrorAPI(Exception):
    """Error devuelto por la API, con su código HTTP y el mensaje del servicio."""

    def __init__(self, estado: int, mensaje: str):
        super().__init__(f"HTTP {estado}: {mensaje}")
        self.estado = estado
        self.mensaje = mensaje

class ClienteIA:
    """Encapsula las llamadas de listado de modelos, generación y embeddings.

    Args:
        base_url: URL base de la API, por ejemplo "https://api.openai.com/v1".
        clave_api: clave de acceso. Si es None, se lee de la variable OPENAI_API_KEY.
        modelo_chat: modelo de generación. Si es None, se lee de MODELO_CHAT.
        modelo_embeddings: modelo de embeddings. Si es None, se lee de MODELO_EMBEDDINGS.
        timeout: segundos máximos de espera por solicitud.
        http: cliente httpx ya construido; las pruebas lo usan para simular la API.
    """

    def __init__(self, base_url: str = "https://api.openai.com/v1", clave_api: str | None = None,
                 modelo_chat: str | None = None, modelo_embeddings: str | None = None,
                 timeout: float = 30.0, http: httpx.Client | None = None):
        self.clave_api = clave_api or os.environ.get("OPENAI_API_KEY")
        if not self.clave_api:
            raise ValueError("Falta OPENAI_API_KEY: defínela en el entorno, nunca en el código.")
        self.modelo_chat = modelo_chat or os.environ.get("MODELO_CHAT")
        self.modelo_embeddings = modelo_embeddings or os.environ.get("MODELO_EMBEDDINGS")
        self.http = http or httpx.Client(base_url=base_url, timeout=timeout)
        self.http.headers["Authorization"] = f"Bearer {self.clave_api}"

    def _revisar(self, respuesta: httpx.Response) -> dict:
        """Devuelve el JSON de la respuesta o lanza ErrorAPI si el estado es 400 o más."""
        if respuesta.status_code >= 400:
            raise ErrorAPI(respuesta.status_code, respuesta.text[:300])
        return respuesta.json()

    def listar_modelos(self) -> list[str]:
        """Devuelve los identificadores de los modelos disponibles (GET /models)."""
        datos = self._revisar(self.http.get("/models"))
        return [m["id"] for m in datos.get("data", [])]

    def generar(self, mensajes: list[dict], temperature: float = 0.2, max_tokens: int = 300) -> dict:
        """Envía una conversación al endpoint de chat (POST /chat/completions).

        Args:
            mensajes: lista de {"role": "system" | "user" | "assistant", "content": str}.
            temperature: aleatoriedad de la respuesta; baja para resúmenes consistentes.
            max_tokens: máximo de tokens de la respuesta.

        Returns:
            {"texto": str, "tokens": dict} con el texto generado y el uso de tokens.
        """
        if not self.modelo_chat:
            raise ValueError("Falta el modelo: define MODELO_CHAT.")
        datos = self._revisar(self.http.post("/chat/completions", json={
            "model": self.modelo_chat, "messages": mensajes,
            "temperature": temperature, "max_tokens": max_tokens,
        }))
        return {"texto": datos["choices"][0]["message"]["content"], "tokens": datos.get("usage", {})}

    def embeddings(self, textos: list[str]) -> list[list[float]]:
        """Devuelve un vector por texto, en el mismo orden de entrada (POST /embeddings)."""
        if not self.modelo_embeddings:
            raise ValueError("Falta el modelo: define MODELO_EMBEDDINGS.")
        datos = self._revisar(self.http.post("/embeddings", json={
            "model": self.modelo_embeddings, "input": textos,
        }))
        return [d["embedding"] for d in sorted(datos["data"], key=lambda d: d["index"])]
```

**`test_cliente_ia.py` de referencia** (sin conexión, con `httpx.MockTransport`):

```python
import httpx
import pytest

from cliente_ia import ClienteIA, ErrorAPI

def cliente_simulado(cuerpo: dict, estado: int = 200, registro: list | None = None) -> ClienteIA:
    """Crea un ClienteIA cuyas solicitudes responde una API falsa."""
    def responder(solicitud: httpx.Request) -> httpx.Response:
        if registro is not None:
            registro.append(solicitud)
        return httpx.Response(estado, json=cuerpo)

    http = httpx.Client(base_url="https://api.test/v1", transport=httpx.MockTransport(responder))
    return ClienteIA(clave_api="clave-de-prueba", modelo_chat="modelo-x",
                     modelo_embeddings="embeddings-x", http=http)

def test_generar_devuelve_texto_tokens_y_autentica():
    registro = []
    cliente = cliente_simulado({"choices": [{"message": {"content": "Resumen"}}],
                                "usage": {"total_tokens": 42}}, registro=registro)
    respuesta = cliente.generar([{"role": "user", "content": "hola"}])
    assert respuesta == {"texto": "Resumen", "tokens": {"total_tokens": 42}}
    assert registro[0].method == "POST"
    assert registro[0].url.path == "/v1/chat/completions"
    assert registro[0].headers["Authorization"] == "Bearer clave-de-prueba"

def test_embeddings_respeta_el_orden_de_entrada():
    cliente = cliente_simulado({"data": [{"index": 1, "embedding": [0.3]},
                                         {"index": 0, "embedding": [0.1]}]})
    assert cliente.embeddings(["a", "b"]) == [[0.1], [0.3]]

def test_listar_modelos_usa_get():
    registro = []
    cliente = cliente_simulado({"data": [{"id": "m1"}, {"id": "m2"}]}, registro=registro)
    assert cliente.listar_modelos() == ["m1", "m2"]
    assert registro[0].method == "GET"

def test_error_http_se_informa_con_su_codigo():
    cliente = cliente_simulado({"error": {"message": "clave inválida"}}, estado=401)
    with pytest.raises(ErrorAPI) as error:
        cliente.generar([{"role": "user", "content": "hola"}])
    assert error.value.estado == 401

def test_sin_clave_no_arranca(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(ValueError):
        ClienteIA()
```

Salida esperada: `5 passed`.

**Uso con Hugging Face.** La misma clase sirve con cualquier API compatible con el formato
de OpenAI cambiando `base_url`, la clave y el modelo. `PENDIENTE:` el tutor confirma en la
documentación vigente de Hugging Face (Inference Providers) la URL base compatible y un
modelo de ejemplo antes de publicar la actividad; las URL de ese servicio han cambiado.

**Nota sobre parámetros.** Algunos modelos recientes piden `max_completion_tokens` en vez de
`max_tokens` o no aceptan `temperature`. El participante lo comprueba en la documentación
del modelo que use: es parte del indicador 2.1.

**Errores típicos:** la clave escrita en el código o en el notebook (falla grave, criterio 2
de la rúbrica); pruebas que llaman a la API real y fallan sin internet; no revisar el código
de estado y leer `choices` de una respuesta de error.
