# PF1822 · Módulo 2 · R02 — Infografía "Ruta del módulo" (C3)

**Estado:** borrador · **Exigencia:** C3 aspectos motivacionales (Anexo N°7, num. 7 c): un
ambiente intuitivo, con íconos, multimedia e imágenes, que invite a avanzar.

---

## R02 · Infografía "Ruta del módulo 2"

**Formato:** imagen vertical (1080 × 1920 px), descargable en PDF, con esta versión en texto
para lectores de pantalla. Un ícono por estación, repetido en los títulos del LMS.

**Encabezado**
> MÓDULO 2 · INTRODUCCIÓN A MODELOS GENERATIVOS Y CONSUMO POR API · 21 h
> *Tu misión: construir el resumidor de tickets de Nube Sur.*

**Bloque "Al terminar serás capaz de"** (competencia del módulo, textual):
> IMPLEMENTAR LA ARQUITECTURA BÁSICA DE UNA APLICACIÓN QUE INTEGRE MODELOS DE IA MEDIANTE
> APIS Y PREPROCESAMIENTO DE TEXTO PARA CONSUMO POR MODELOS DE LENGUAJE, GARANTIZANDO EL
> CONSUMO EFICIENTE Y LA EVALUACIÓN DE RESULTADOS EN UN ENTORNO DE DESARROLLO DE SOFTWARE

**Bloque "Tu ruta"**

| Estación | Ícono | Título | Qué haces | Qué te llevas | Horas |
| --- | --- | --- | --- | --- | --- |
| 1 | Plano con cajas conectadas | Entender y diseñar | Conoces los tipos de modelos y dibujas la arquitectura del resumidor | Cuadro de modelos + diagrama | 4 h |
| 2 | Llave y flecha hacia una nube | Conectar | Programas `ClienteIA`: GET, POST, embeddings, pruebas | Módulo Python con pruebas en verde | 6 h |
| 3 | Globo de diálogo con ejemplos | Pedir bien | Prompts zero-shot y few-shot, y el efecto de temperature | Registro de iteraciones | 5 h |
| 4 | Embudo y gráfico de barras | Limpiar y medir | Pipeline de limpieza y métricas ROUGE y BLEU | Tabla de resultados + recomendación | 6 h |

**Bloque "Cómo te acompañamos"**
- 4 sesiones en vivo de 1,5 h, una por estación. `PENDIENTE:` días y horarios por institución.
- Revisión de tu código en máximo 2 días hábiles.
- Foro de dudas por estación, respondido por el tutor.

**Bloque "Cómo te evaluamos"**
- Rúbrica de tu solución en las actividades 1 y 2 (35 %).
- Proyecto "Asistente de preguntas frecuentes" al cierre (45 %).
- Prueba de conceptos y lectura de código (20 %).
- Tu portafolio y tu repositorio quedan publicados para mostrar a un empleador.

**Pie**
> Herramientas del módulo: Python · httpx · pytest · spaCy · NLTK · rouge-score · Git y GitHub · API de OpenAI y Hugging Face.
> Regla de oro: tu clave nunca va en el código.
> Empieza aquí → autodiagnóstico + notebook guiado.
