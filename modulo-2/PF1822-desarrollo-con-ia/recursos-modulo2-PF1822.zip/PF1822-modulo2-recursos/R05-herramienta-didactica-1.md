# PF1822 · Módulo 2 · R05 — Herramienta didáctica 1 (C4)

**Estado:** borrador · **Va en:** Anexo N°2, sección VI c), **con el enlace al LMS**
**Guía:** Anexo N°7, num. 7 · **Para el 7,0:** 2 herramientas distintas y **ambas** efectivas
para adquirir la habilidad. Si solo una lo es, la nota baja a 5,0.

1. **Notebook guiado "Tu primera llamada a un modelo"** (Colab o JupyterLab): celdas que el participante ejecuta y completa, con celdas de autocomprobación que le dicen si lo logró. Es efectivo porque la habilidad de AE2 y AE4 es escribir y ejecutar código que consume una API y procesa texto: el notebook la ejercita directamente y termina en el código base de las actividades 1 y 2.
2. **Video interactivo "Del prompt a la respuesta"**: 6 minutos con 5 preguntas incrustadas. Es efectivo porque obliga a leer una solicitud y una respuesta reales de la documentación y a predecir el efecto de un prompt y de `temperature` antes de verlo, que son las habilidades de AE2 (2.1) y AE3.

---

## Herramienta 1 · Notebook guiado "Tu primera llamada a un modelo"

**AE:** AE2 y AE4 · **Indicadores:** 2.1, 2.2, 4.1, 4.2 · **Duración:** 60 a 90 minutos
**Formato:** notebook publicado en el LMS con enlace para abrirlo en Colab o descargarlo para
JupyterLab. Cada sección termina con una celda de autocomprobación con `assert` y un mensaje
que explica qué revisar si falla.

| Sección | Qué hace el participante | Celda de autocomprobación |
| --- | --- | --- |
| 0 · Preparar | Instala `httpx`, carga la clave desde el entorno (en Colab, desde *Secrets* con `userdata.get("OPENAI_API_KEY")`; en local, con una variable de entorno) y define `MODELO_CHAT` y `MODELO_EMBEDDINGS`. | `assert os.environ.get("OPENAI_API_KEY"), "La clave no está en el entorno: revisa Secrets o tu .env"` y una comprobación de que la clave **no** aparece escrita en ninguna celda. |
| 1 · GET | Lista los modelos con `httpx.get(".../models", headers=...)` y muestra los 5 primeros identificadores. | `assert r.status_code == 200, f"Estado {r.status_code}: revisa la clave o la URL"` |
| 2 · POST de generación | Arma a mano el JSON de una solicitud a `/chat/completions` con un mensaje de sistema y uno de usuario; imprime la respuesta completa y marca en ella `choices`, `message`, `content` y `usage`. | `assert "choices" in datos and datos["choices"][0]["message"]["content"]` |
| 3 · Tokens y costo | Lee `usage` y calcula cuántos tokens de entrada y de salida consumió; repite con un mensaje el doble de largo. | El participante escribe la relación que observó; la celda verifica que `total_tokens` aumentó. |
| 4 · Temperature | Ejecuta el mismo prompt 3 veces con `temperature` 0,2 y 3 veces con 0,9; compara las respuestas. | Pregunta en el notebook: "¿con cuál variaron más?" y verifica que haya 6 respuestas guardadas. |
| 5 · Embeddings | Obtiene embeddings de tres frases (dos parecidas y una distinta) y calcula la similitud de coseno entre ellas. | `assert sim(parecidas) > sim(distintas), "Las frases parecidas deberían estar más cerca"` |
| 6 · Errores | Hace una solicitud con una clave inválida a propósito y lee el código y el mensaje de error. | `assert r.status_code == 401` y el participante anota qué significa 401, 429 y 500. |
| 7 · Limpiar texto | Aplica `limpiar()` (entregada) al ticket T1 con HTML y firma; compara antes y después. | `assert "<p>" not in limpio and "@" not in limpio` |
| 8 · Tokenizar | Tokeniza con spaCy, quita stopwords, obtiene lemas y bigramas del ticket limpio. | `assert "iniciar" in tokens` y verificación de que ninguna stopword quedó en la lista. |
| 9 · Hacia la actividad 1 | Copia lo que funcionó a un archivo `cliente_ia.py` con una primera versión de `ClienteIA`. | Mensaje final con el enlace a la actividad 1. |

**Seguridad (se explica en la sección 0):** la clave nunca se escribe en una celda; un
notebook compartido con una clave escrita la expone a cualquiera que lo abra.
