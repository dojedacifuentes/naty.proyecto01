# PF1822 · Módulo 2 · R01 — Video de bienvenida (C3)

**Estado:** borrador · **Exigencia:** C3 aspectos motivacionales (Anexo N°7, num. 7 c): un
ambiente intuitivo, con íconos, multimedia e imágenes, que invite a avanzar.

---

## R01 · Video de bienvenida (1 minuto 40 segundos)

**Formato:** presentador (docente o avatar) y pantalla con código. Primera pieza del módulo en
el LMS. Subtítulos obligatorios. **Tono:** de colega desarrollador; muestra antes de explicar.

| Tiempo | Imagen | Locución |
| --- | --- | --- |
| 0:00–0:10 | Presentador a cámara | "Hola. Bienvenida, bienvenido al módulo 2: Introducción a modelos generativos y consumo por API." |
| 0:10–0:30 | Una bandeja con cientos de tickets de soporte, largos y con firmas | "Imagina la mesa de ayuda de una empresa de software que recibe cientos de tickets al día. Nadie alcanza a leerlos todos antes de priorizar. La empresa se llama Nube Sur, es inventada, y va a ser tu cliente durante el módulo." |
| 0:30–0:55 | Terminal: se ejecuta un script, entra un ticket y sale un resumen de una línea | "En estas 21 horas vas a construir su resumidor de tickets: una aplicación que limpia cada ticket, le pide a un modelo de lenguaje un resumen por API y mide si el resumen es bueno." |
| 0:55–1:15 | Infografía de la ruta: cuatro estaciones | "Cuatro estaciones: entender los modelos y diseñar la arquitectura, programar el cliente de la API, escribir buenos prompts, y limpiar y medir texto. Cada estación deja código en tu portafolio." |
| 1:15–1:30 | Tablero del laboratorio con puntajes ROUGE e insignias | "Al final, el laboratorio: pruebas estrategias de prompt, las mides y compites en el tablero por el mejor resumen. Pero ojo: gana quien decide con evidencia." |
| 1:30–1:40 | Presentador; botón "Empezar estación 1" | "Primer paso: mira la ruta, completa el autodiagnóstico y abre el notebook guiado. Nos vemos en la primera sesión en vivo." |

**Notas de producción:** si se usa avatar, una pieza de 60 a 120 segundos por módulo; no
reemplaza al tutor. Placa final con nombre del tutor y horarios, que completa cada
institución. `PENDIENTE:` nombre del tutor y horarios, por institución.
