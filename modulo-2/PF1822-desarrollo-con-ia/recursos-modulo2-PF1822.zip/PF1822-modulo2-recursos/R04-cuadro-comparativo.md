# PF1822 · Módulo 2 · R04 — Cuadro comparativo (C4 d))

**Estado:** borrador · **Exigencia:** C4 d) uso de los medios (Anexo N°7, num. 7):
presentaciones y cuadro comparativo como medios para transferir el aprendizaje.
**Formato de cada cápsula:** presentación narrada de 8 a 12 minutos (11 o 12 láminas: portada, aprendizaje esperado y criterios textuales, una por tema rotulada con el contenido del plan textual, y la tarea), con
transcripción. Una por aprendizaje esperado. Contenidos tomados de la ficha SIPFOR del
módulo (`01-ficha-sipfor.md`).

---

## R04 · Cuadro comparativo: familias de modelos generativos

**AE1 · indicador 1.1.** En la actividad 1 el participante agrega una columna con un caso de
uso para Nube Sur en cada fila.

| Familia | Cómo genera | Salida típica | Casos de uso en una organización | Ejemplos de tecnologías | A considerar |
| --- | --- | --- | --- | --- | --- |
| **Autorregresivos** | Predicen el siguiente token a partir de los anteriores, uno a la vez | Texto, código | Resúmenes, respuestas a clientes, generación de código y de pruebas | Modelos de lenguaje tipo GPT, Llama o Mistral | Pueden inventar datos; el costo depende de los tokens |
| **De difusión** | Parten de ruido y lo refinan en muchos pasos hasta llegar a la salida | Imágenes, audio | Imágenes para marketing, prototipos visuales | Stable Diffusion, biblioteca Diffusers | Más cómputo por resultado; derechos de uso de las imágenes |
| **Transformers codificadores** | Convierten un texto en una representación numérica; no generan texto libre | Embeddings, clasificación | Buscar tickets parecidos, clasificar por tema | Familia BERT, modelos de embeddings | Base de la búsqueda semántica del módulo 3 del plan |
| **Transformers codificador–decodificador** | Leen una entrada completa y generan una salida transformada | Texto a texto, audio a texto | Traducción, resumen, transcripción | Familias T5 y BART, Whisper | Buenos para tareas acotadas de transformación |

**Nota para el tutor:** "autorregresivo" y "de difusión" describen **cómo se genera**; 
"transformer" describe **la arquitectura**. La mayoría de los modelos de lenguaje actuales son
transformers autorregresivos. El plan los nombra como tres tipos: conviene explicar esta
superposición en la lámina 4 para que la clasificación no confunda.
