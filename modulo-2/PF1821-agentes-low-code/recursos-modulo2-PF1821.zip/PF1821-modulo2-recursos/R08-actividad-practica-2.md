# PF1821 · Módulo 2 · R08 — Actividad práctica 2 (C2)

**Estado:** borrador · **Va en:** Anexo N°2, sección VI b) · **Guía:** Anexo N°7, num. 7, pág. 109
**Para el 7,0:** 2 actividades prácticas distintas que permitan adquirir la habilidad.
Siguen el ejemplo de la guía (pág. 110): una de **resolución de problemas** apoyada en
tutoriales y videos, y otra de **análisis de caso** con **gamificación y simulación**,
ambas con respuesta modelada.

| | Actividad 1 | Actividad 2 |
| --- | --- | --- |
| Nombre | Del formulario a la base de datos | Rescate del workflow roto |
| Técnica | Resolución de problemas | Análisis de caso + gamificación |
| AE que cubre | AE1, AE2, AE3 | AE1, AE3, AE4 |
| Indicadores | 1.1, 2.1, 2.2, 2.3, 3.1, 3.2, 3.3, 3.4 | 1.1, 3.3, 4.1, 4.2, 4.3 |
| Tramo del módulo | 2 y 3 (semanas 1–2) | 4 (semana 2–3) |
| Tiempo estimado | 5 h (2 h guiadas + 3 h autónomas) | 4 h (1,5 h sincrónica + 2,5 h autónomas) |
| Apoyos | Tutorial R05, cápsulas R03 | Video interactivo R06 |
| Producto | 2 workflows exportados + captura de Supabase + nota breve | Workflow reparado + bitácora de depuración |
| Se evalúa con | Rúbrica de workflow (B2-1) | Rúbrica de workflow (B2-1) + bitácora (B4-d) |

---

## Actividad 2 · Rescate del workflow roto

### Enunciado para el participante

El practicante anterior de Mercado Austral dejó un workflow que enruta los pedidos: los
mayoristas van a ventas, los de regiones a despacho regional y el resto a bodega de
Santiago. Funcionó una semana y después empezó a fallar: hay pedidos que se pierden,
mayoristas clasificados como minoristas y ejecuciones en rojo. Ventas está molesta.

Recibes el workflow exportado (`pedidos_enrutados_v0.json`) y **cinco misiones**. Cada
misión es una falla real escondida en el workflow. Para cada una tienes que:
**detectarla** (qué síntoma ves y con qué herramienta de n8n lo viste), **explicar la causa**
y **corregirla**. Todo va a tu bitácora de depuración.

| Misión | Pista | Puntos |
| --- | --- | --: |
| 1 · Los mayoristas invisibles | Un pedido de $219.000 terminó en bodega de Santiago. | 20 |
| 2 · Nadie tiene correo | Todos los pedidos salen por la rama "datos inválidos". | 20 |
| 3 · El pedido de Isla de Pascua | Un pedido con `tipo_cliente` "distribuidor" desapareció sin error. | 20 |
| 4 · Los pedidos clonados | Al enriquecer con la zona de despacho, cada pedido aparece varias veces. | 20 |
| 5 · La ejecución en rojo | Supabase rechaza algunos pedidos y el workflow se detiene entero. | 20 |
| Bonus · Trazabilidad | Que cada fila guardada diga por qué ruta pasó y en qué ejecución. | +10 |

Cada misión vale 20 puntos: 5 por detectar, 5 por explicar y 10 por corregir. Con 60
puntos obtienes la insignia **Depurador/a**; con 100 o más, **Rescatista de workflows**.

**Cómo debería funcionar el workflow (requerimiento):**
1. Recibir el pedido (Webhook) y normalizarlo (Edit Fields).
2. Validar: el email contiene "@" y la cantidad es mayor que 0. Si no, va a `pedidos_rechazados`.
3. Enriquecer con la zona de despacho de la comuna (tabla `comunas` en Supabase) y unir por el campo `comuna`.
4. Enrutar con Switch: **mayorista** si `tipo_cliente` es "mayorista" **o** el total es
   de $150.000 o más; **regiones** si la comuna no es de la Región Metropolitana;
   **bodega RM** para el resto; y todo lo que no calce, a **revisión manual**.
5. Guardar en `pedidos` con el campo `ruta`.

### Insumos que entrega el LMS

- `pedidos_enrutados_v0.json`: el workflow con las cinco fallas (lo arma el tutor a partir
  de la respuesta modelada, introduciendo exactamente las fallas de la tabla de abajo).
- Seis pedidos de prueba para fijar como datos (*pin data*) en el Webhook, incluido uno
  mayorista por monto ($219.000), uno de Temuco, uno con `tipo_cliente` "distribuidor" y
  uno con `cantidad` escrita "3 " con espacio.
- Tabla `comunas` con columnas `comuna` y `zona` (RM o Regiones).
- Plantilla de bitácora (ver `R12-retroalimentacion.md`, producto d).

### Respuesta modelada

| Misión | Síntoma | Cómo se detecta | Causa | Corrección | Ind. |
| --- | --- | --- | --- | --- | --- |
| 1 | El pedido de $219.000 cae en "bodega RM" | Abrir la ejecución y ver la entrada del Switch: `total` aparece como `"219000"` entre comillas | En Edit Fields el campo `total` está declarado como **String**; la regla del Switch compara números y la condición no se cumple | Declarar `total` como **Number** en Edit Fields (o activar *Convert types where required* en la regla) | 4.2 |
| 2 | Todo sale por "datos inválidos" | En el nodo If, la vista previa de la expresión muestra `undefined` | La condición usa `{{ $json.Email }}` con mayúscula; el campo se llama `email` | Cambiar a `{{ $json.email }}` y comprobarlo con el pedido fijado | 3.3 |
| 3 | El pedido "distribuidor" no aparece en ninguna tabla ni da error | Historial de ejecuciones: la ejecución termina en verde pero el Switch no entrega ningún ítem | El Switch no tiene salida de respaldo: lo que no calza con ninguna regla se descarta en silencio | En *Options* del Switch, *Fallback Output* = *Extra Output* y conectarla a "revisión manual" | 4.1 |
| 4 | Cada pedido aparece repetido tantas veces como comunas hay | Contar los ítems de salida del Merge: 6 pedidos × N comunas | El Merge está en modo *Append* (o *All Possible Combinations*) en vez de unir por campo | Modo *Combine* → *Matching Fields*, campo `comuna` en ambas entradas | 3.1 |
| 5 | Supabase rechaza el pedido con `cantidad` "3 " y todo se detiene | Ejecución en rojo; el error del nodo dice `invalid input syntax for type integer` | `cantidad` llega como texto con espacio y no hay manejo de errores | En Edit Fields, `cantidad` (Number) = `{{ Number(String($json.cantidad).trim()) }}`; en *Settings* del nodo Supabase, *On Error* = *Continue (using error output)* y enviar esa salida a `pedidos_rechazados` con el mensaje de error | 4.3 |
| Bonus | No se sabe por qué ruta pasó cada pedido | Mirar la tabla `pedidos` | Falta registrar la decisión | En cada rama, Edit Fields agrega `ruta` ("mayorista", "regiones", "bodega RM", "revisión") y `id_ejecucion` = `{{ $execution.id }}` | 4.3 |

**Reglas del Switch en la versión corregida** (modo *Rules*, se envía a la primera regla que
se cumple):

| Salida | Regla |
| --- | --- |
| 0 · mayorista | `tipo_cliente` (String) *is equal to* "mayorista" **OR** `total` (Number) *is greater than or equal to* 150000 |
| 1 · regiones | `zona` (String) *is equal to* "Regiones" |
| 2 · bodega RM | `tipo_cliente` (String) *is equal to* "minorista" |
| respaldo · revisión manual | *Fallback Output: Extra Output* |

**Ejemplo de una entrada de bitácora de nivel logrado (misión 3):**

> *Síntoma:* el pedido de prueba con `tipo_cliente` "distribuidor" no quedó en ninguna
> tabla y la ejecución salió en verde. *Detección:* en *Executions* abrí la ejecución y vi
> que el Switch recibió 6 ítems y entregó 5. *Causa:* ninguna regla acepta "distribuidor"
> y el Switch no tenía salida de respaldo, así que lo descartó sin avisar. *Corrección:*
> activé *Fallback Output → Extra Output* y la conecté a una rama que registra el pedido en
> `revision_manual`. *Prueba:* volví a ejecutar con los 6 pedidos fijados: 6 entran y 6
> salen. *Aprendizaje:* un workflow en verde no significa que no perdió datos; hay que
> contar ítems de entrada y salida.

**Qué distingue una respuesta débil:** corrige sin explicar la causa, o "arregla" la
misión 3 agregando "distribuidor" a la regla de minoristas: resuelve el caso de prueba pero
el próximo valor inesperado se vuelve a perder. El indicador 4.1 pide la ruta de respaldo.
