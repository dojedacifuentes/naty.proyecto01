# PF1821 · Módulo 2 · R04 — Cuadro comparativo (C4 d))

**Estado:** borrador · **Exigencia:** C4 d) uso de los medios (Anexo N°7, num. 7):
presentaciones y cuadro comparativo como medios para transferir el aprendizaje.
**Formato de cada cápsula:** presentación narrada de 8 a 12 minutos (11 o 12 láminas: portada, aprendizaje esperado y criterios textuales, una por tema rotulada con el contenido del plan textual, y la tarea), con
transcripción. Una por aprendizaje esperado, en el orden de la ruta. Contenidos tomados de
la ficha SIPFOR del módulo (`01-ficha-sipfor.md`).

---

## R04 · Cuadro comparativo: n8n, Make y Zapier

**AE1 · indicador 1.3.** Se entrega como tabla en el LMS; en la actividad 1 el
participante agrega una fila propia y escribe su conclusión para Mercado Austral.

| Criterio | n8n | Make | Zapier |
| --- | --- | --- | --- |
| Dónde corre | En la nube del proveedor **o** en infraestructura propia (autoalojado) | Solo en la nube del proveedor | Solo en la nube del proveedor |
| Licencia | Código disponible bajo licencia *fair-code*; uso interno gratuito si se autoaloja | Servicio comercial | Servicio comercial |
| Control de los datos | Total si se autoaloja: los datos no salen de la empresa | Pasan por los servidores del proveedor | Pasan por los servidores del proveedor |
| Forma de construir | Canvas de nodos con ramas, uniones y bucles | Escenarios visuales con módulos y enrutadores | Flujos ("Zaps") mayormente lineales, con rutas y filtros |
| Lógica propia | Nodo Code (JavaScript o Python) y expresiones en cualquier campo | Funciones y fórmulas integradas | Pasos de código (JavaScript o Python) |
| Integraciones | Cientos de nodos nativos + HTTP Request para cualquier API | Miles de aplicaciones | La mayor cantidad de aplicaciones listas |
| Unidad de cobro en la nube | Por ejecución del workflow | Por consumo de cada acción | Por tarea ejecutada |
| Curva de aprendizaje | Media: pide entender datos y expresiones | Media | Baja para flujos simples |

**Conclusión modelo para el caso:** para Mercado Austral conviene n8n, porque maneja datos
de clientes que puede mantener en su propia infraestructura, porque un workflow con muchas
ramas se cobra por ejecución y no por cada paso, y porque la lógica de enrutamiento que
necesita (tipos, montos, comunas) se resuelve con expresiones y el nodo Code sin salir de
la herramienta.

`PENDIENTE:` las cifras de integraciones y los precios cambian seguido; el tutor verifica
las unidades de cobro vigentes en el sitio de cada proveedor antes de publicar el cuadro.
