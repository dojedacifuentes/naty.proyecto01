# PF1821 · Módulo 2 · R07 — Actividad práctica 1 (C2)

**Estado:** borrador · **Va en:** Anexo N°2, sección VI b) · **Guía:** Anexo N°7, num. 7, pág. 109
**Para el 7,0:** 2 actividades prácticas distintas que permitan adquirir la habilidad.
Siguen el ejemplo de la guía (pág. 110): una de **resolución de problemas** apoyada en
tutoriales y videos, y otra de **análisis de caso** con **gamificación y simulación**,
ambas con respuesta modelada.

| | Actividad 1 | Actividad 2 |
| --- | --- | --- |
| Nombre | Del formulario a la base de datos | Rescate del workflow roto |
| Técnica | Resolución de problemas | Análisis de caso + gamificación |
| AE que cubre | AE1, AE2, AE3 | AE1, AE3, AE4 |
| Indicadores | 1.1, 2.1, 2.2, 2.3, 3.1, 3.2, 3.3, 3.4 | 1.1, 3.3, 4.1, 4.2, 4.3 |
| Tramo del módulo | 2 y 3 (semanas 1–2) | 4 (semana 2–3) |
| Tiempo estimado | 5 h (2 h guiadas + 3 h autónomas) | 4 h (1,5 h sincrónica + 2,5 h autónomas) |
| Apoyos | Tutorial R05, cápsulas R03 | Video interactivo R06 |
| Producto | 2 workflows exportados + captura de Supabase + nota breve | Workflow reparado + bitácora de depuración |
| Se evalúa con | Rúbrica de workflow (B2-1) | Rúbrica de workflow (B2-1) + bitácora (B4-d) |

---

## Actividad 1 · Del formulario a la base de datos

### Enunciado para el participante

Mercado Austral (empresa ficticia) recibe pedidos por un formulario web. Hoy una persona
los copia a una planilla y todos los viernes suma a mano cuánto se vendió por comuna para
avisarle al sistema de facturación, que solo acepta archivos XML. Tu trabajo es reemplazar
ese proceso manual por dos workflows en n8n.

**Parte A — Antes de construir (AE1).** Lee el caso y responde en 5 a 8 líneas: ¿qué tres
tareas de este proceso conviene automatizar y qué gana la empresa con cada una (tiempo,
errores evitados, información nueva)?

**Parte B — Workflow "Pedido a registro" (AE2 y AE3).** Construye un workflow que:
1. reciba un pedido desde un formulario de n8n con estos campos: `nombre`, `email`,
   `comuna`, `tipo_cliente` (minorista o mayorista), `producto`, `cantidad`, `precio_unitario`;
2. normalice los datos: email en minúsculas y sin espacios, comuna sin espacios al inicio
   ni al final, cantidad y precio como números, y un campo nuevo `total`;
3. guarde el pedido como una fila nueva en la tabla `pedidos` de Supabase.

**Parte C — Workflow "Resumen semanal" (AE3).** Construye un segundo workflow que:
1. descargue el archivo `pedidos_historicos.csv` desde el enlace publicado en el LMS;
2. descarte los pedidos sin email;
3. calcule, por comuna, la cantidad de pedidos y el total vendido;
4. entregue ese resumen en formato XML para facturación.

**Entrega:** los dos workflows exportados (menú del workflow → *Download*), una captura de
la tabla `pedidos` en Supabase con al menos tres filas creadas por tu workflow, y tu
respuesta a la parte A.

### Insumos que entrega el LMS

**Tabla `pedidos` en Supabase** (el tutor la crea en el proyecto del curso o la entrega
como script SQL):

```sql
create table pedidos (
  id              bigint generated always as identity primary key,
  creado_en       timestamptz not null default now(),
  nombre          text not null,
  email           text not null,
  comuna          text not null,
  tipo_cliente    text not null check (tipo_cliente in ('minorista', 'mayorista')),
  producto        text not null,
  cantidad        integer not null check (cantidad > 0),
  precio_unitario integer not null,
  total           integer not null
);
```

**Archivo `pedidos_historicos.csv`** (datos ficticios; los correos usan el dominio
reservado `.test`):

```csv
id,fecha,nombre,email,comuna,tipo_cliente,producto,cantidad,precio_unitario
1,2026-09-01,Ana Rojas,ana.rojas@correo.test,Ñuñoa,minorista,Café en grano 1 kg,2,12500
2,2026-09-01,Pedro Soto,PEDRO.SOTO@correo.test,Maipú,minorista,Té verde 100 u,3,4200
3,2026-09-02,Almacén El Sol,compras@elsol.test,Temuco,mayorista,Azúcar 25 kg,10,21900
4,2026-09-02,Lucía Díaz,,Ñuñoa,minorista,Café en grano 1 kg,1,12500
5,2026-09-03,Minimarket Doña Rosa,rosa@donarosa.test,Maipú,mayorista,Arroz 25 kg,8,24500
6,2026-09-03,Jorge Muñoz,jorge.munoz@correo.test,Ñuñoa ,minorista,Yerba mate 1 kg,2,6900
7,2026-09-04,Almacén El Sol,compras@elsol.test,Temuco,mayorista,Aceite 5 L,6,15990
8,2026-09-04,Camila Pérez,camila.perez@correo.test,Valparaíso,minorista,Té verde 100 u,1,4200
```

El archivo trae dos trampas a propósito: la fila 4 no tiene email y la fila 6 tiene
"Ñuñoa " con un espacio al final.

### Respuesta modelada

**Parte A (ejemplo de respuesta de nivel logrado).**
1. *Registrar cada pedido*: hoy se copia a mano; automatizarlo elimina la digitación y los
   pedidos perdidos o duplicados, y deja el registro disponible al instante.
2. *Validar y normalizar los datos*: correos con mayúsculas o comunas con espacios rompen
   los reportes; normalizar en la entrada evita corregir después.
3. *Consolidar las ventas por comuna para facturación*: hoy toma horas cada viernes y se
   equivoca; automatizado es un resumen exacto y en el formato que facturación exige.

**Parte B — workflow de referencia "Pedido a registro"** (4 nodos):

| # | Nodo | Configuración clave |
| --- | --- | --- |
| 1 | **n8n Form Trigger** | Título "Nuevo pedido". Campos con esas etiquetas exactas: `nombre`, `email` (tipo Email), `comuna`, `tipo_cliente` (Dropdown: minorista, mayorista), `producto`, `cantidad` (Number), `precio_unitario` (Number). |
| 2 | **Edit Fields (Set)** | Modo *Manual Mapping*. `email` (String) = `{{ $json.email.trim().toLowerCase() }}` · `comuna` (String) = `{{ $json.comuna.trim() }}` · `cantidad` (Number) = `{{ Number($json.cantidad) }}` · `precio_unitario` (Number) = `{{ Number($json.precio_unitario) }}` · `total` (Number) = `{{ Number($json.cantidad) * Number($json.precio_unitario) }}` · conservar `nombre`, `tipo_cliente` y `producto`. |
| 3 | **Supabase** | Credencial del proyecto del curso. Operación *Create a row*, tabla `pedidos`, *Auto-map input data to columns*. |
| 4 | **Form Ending** (opcional) | Mensaje "Pedido recibido. Te contactaremos a {{ $('Edit Fields').item.json.email }}". |

Salida esperada del nodo 2 para un pedido de prueba (2 × Café en grano 1 kg a $12.500,
comuna escrita "  Ñuñoa "):

```json
{ "nombre": "Ana Rojas", "email": "ana.rojas@correo.test", "comuna": "Ñuñoa",
  "tipo_cliente": "minorista", "producto": "Café en grano 1 kg",
  "cantidad": 2, "precio_unitario": 12500, "total": 25000 }
```

**Parte C — workflow de referencia "Resumen semanal"** (6 nodos):

| # | Nodo | Configuración clave |
| --- | --- | --- |
| 1 | **Manual Trigger** | Para ejecutarlo a pedido (en producción se cambia por *Schedule Trigger*, viernes 18:00). |
| 2 | **HTTP Request** | GET al enlace del CSV. *Response Format*: File. |
| 3 | **Extract from File** | Operación *Extract From CSV*, primera fila como encabezados. |
| 4 | **Filter** | Condición: `{{ $json.email }}` *is not empty*. Descarta la fila 4. |
| 5 | **Edit Fields (Set)** | `comuna` = `{{ $json.comuna.trim() }}` · `total` (Number) = `{{ Number($json.cantidad) * Number($json.precio_unitario) }}`. |
| 6 | **Summarize** | *Fields to Split By*: `comuna`. Agregaciones: *Sum* de `total` y *Count* de `id`. |
| 7 | **XML** | Modo *JSON to XML*. Entrega el resumen como texto XML listo para facturación. |

Resultado correcto del nodo 6 (7 pedidos válidos, $566.540 en total):

| comuna | pedidos | total |
| --- | --: | --: |
| Ñuñoa | 2 | 38.800 |
| Maipú | 2 | 208.600 |
| Temuco | 2 | 314.940 |
| Valparaíso | 1 | 4.200 |

**Errores típicos y cómo se reconocen en la entrega:**
- Sin el `trim()` del nodo 5 aparecen dos grupos: "Ñuñoa" con $25.000 y "Ñuñoa " con
  $13.800. Es la señal de que no se normalizó antes de agrupar (indicador 3.1).
- Sin el Filter aparecen 8 pedidos y Ñuñoa suma $51.300 (indicador 3.3).
- Si `total` quedó como texto, el Summarize concatena en vez de sumar o marca error de tipo
  (indicador 3.3).
- Si Supabase rechaza la fila con `invalid input syntax for type integer`, `cantidad` o
  `precio_unitario` llegaron como texto (indicador 3.4).
