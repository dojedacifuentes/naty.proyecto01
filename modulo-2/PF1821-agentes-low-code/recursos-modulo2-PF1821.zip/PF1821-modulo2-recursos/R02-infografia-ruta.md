# PF1821 · Módulo 2 · R02 — Infografía "Ruta del módulo" (C3)

**Estado:** borrador · **Exigencia:** C3 aspectos motivacionales (Anexo N°7, num. 7 c): un
ambiente intuitivo, con íconos, multimedia e imágenes, que invite a avanzar.

---

## R02 · Infografía "Ruta del módulo 2"

**Formato:** imagen vertical (1080 × 1920 px) en la portada del módulo, descargable en PDF, con
una versión en texto para lectores de pantalla (la de abajo). Un ícono por tramo, los mismos
que se usan en los títulos de cada sección del LMS para que la navegación sea consistente.

### Contenido por bloques

**Encabezado**
> MÓDULO 2 · FUNDAMENTOS DE N8N Y MANIPULACIÓN DE DATOS · 18 h
> *Tu misión: automatizar los pedidos de Mercado Austral.*

**Bloque "Al terminar serás capaz de"** (competencia del módulo, textual):
> CREAR WORKFLOWS BÁSICOS DE AUTOMATIZACIÓN UTILIZANDO N8N, MANIPULANDO DATOS MEDIANTE
> NODOS FUNDAMENTALES E INTEGRANDO BASES DE DATOS BÁSICAS, PARA RESOLVER PROBLEMÁTICAS
> EMPRESARIALES DE ACUERDO CON BUENAS PRÁCTICAS DE AUTOMATIZACIÓN.

**Bloque "Tu ruta"** (cuatro estaciones unidas por una línea, una por aprendizaje):

| Estación | Ícono | Título | Qué haces | Qué te llevas | Horas |
| --- | --- | --- | --- | --- | --- |
| 1 | Lupa sobre un engranaje | Entender | Descubres qué conviene automatizar y comparas n8n con otras herramientas | Mapa de procesos + cuadro comparativo | 3 h |
| 2 | Tres nodos conectados | Construir | Armas tu primer workflow: formulario → datos → base | Workflow "Pedido a registro" | 4 h |
| 3 | Flechas entre JSON, CSV y XML | Transformar | Limpias, conviertes y resumes datos; guardas en Supabase | Resumen por comuna en XML | 6 h |
| 4 | Bifurcación con una lupa | Decidir y depurar | Rutas condicionales y rescate del workflow roto | Workflow reparado + bitácora + insignias | 5 h |

**Bloque "Cómo te acompañamos"**
- 4 sesiones en vivo de 1,5 h, una por estación. `PENDIENTE:` días y horarios por institución.
- Devolución de cada actividad en máximo 2 días hábiles.
- Foro de dudas por estación, respondido por el tutor.

**Bloque "Cómo te evaluamos"**
- Rúbrica de tu workflow en las actividades 1 y 2 (35 %).
- Caso "Devoluciones" al cierre (45 %).
- Prueba de conceptos (20 %).
- Tu portafolio reúne todo: se publica en una URL que puedes mostrar a un empleador.

**Pie**
> Herramientas del módulo: n8n · Supabase · tu navegador.
> Empieza aquí → autodiagnóstico + tutorial "Tu primer workflow".
