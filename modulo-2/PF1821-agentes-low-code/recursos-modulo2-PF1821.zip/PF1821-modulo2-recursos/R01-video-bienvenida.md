# PF1821 · Módulo 2 · R01 — Video de bienvenida (C3)

**Estado:** borrador · **Exigencia:** C3 aspectos motivacionales (Anexo N°7, num. 7 c): un
ambiente intuitivo, con íconos, multimedia e imágenes, que invite a avanzar.

---

## R01 · Video de bienvenida (1 minuto 40 segundos)

**Formato:** video vertical u horizontal, con presentador (docente o avatar) y pantalla de
n8n. Primera pieza del módulo en el LMS, antes de la ruta. Subtítulos obligatorios.
**Tono:** directo, de colega que ya lo hizo; sin tecnicismos antes de mostrarlos.

| Tiempo | Imagen | Locución |
| --- | --- | --- |
| 0:00–0:10 | Presentador a cámara | "Hola. Bienvenida, bienvenido al módulo 2: Fundamentos de n8n y manipulación de datos." |
| 0:10–0:30 | Planilla llena de filas copiadas a mano; un correo "¿llegó mi pedido?" | "Imagina una distribuidora que recibe pedidos por su web y alguien los copia uno por uno a una planilla. Se pierden pedidos, se duplican otros y cada viernes alguien pasa horas sumando ventas. Esa empresa se llama Mercado Austral, es inventada, y va a ser tu cliente durante todo el módulo." |
| 0:30–0:55 | Canvas de n8n: un workflow de 6 nodos que se ejecuta y se pone en verde | "En estas 18 horas vas a reemplazar ese trabajo manual por un workflow en n8n: recibe el pedido, limpia los datos, decide a dónde va y lo guarda en una base de datos. Sin programar, arrastrando nodos." |
| 0:55–1:15 | Infografía de la ruta: cuatro tramos con íconos | "Vamos en cuatro tramos: entender qué conviene automatizar, construir tu primer workflow, transformar datos, y hacer que tu workflow tome decisiones y se deje depurar. Cada tramo deja una pieza en tu portafolio." |
| 1:15–1:30 | Tablero de misiones con insignias "Depurador/a" y "Rescatista de workflows" | "Al final te espera un rescate: un workflow roto con cinco fallas escondidas. Encuéntralas y gana tus insignias." |
| 1:30–1:40 | Presentador a cámara; en pantalla el botón "Empezar tramo 1" | "Tu primer paso: mira la ruta del módulo y completa el autodiagnóstico. Nos vemos en la primera sesión en vivo." |

**Notas de producción:**
- Si se usa avatar, una pieza de 60 a 120 segundos por módulo; no reemplaza al tutor en
  las sesiones sincrónicas (criterio del brainstorm del 24-sep).
- Mostrar el nombre del tutor y el horario de las sesiones en una placa final que cada
  institución completa. `PENDIENTE:` nombre del tutor y horarios, por institución.
